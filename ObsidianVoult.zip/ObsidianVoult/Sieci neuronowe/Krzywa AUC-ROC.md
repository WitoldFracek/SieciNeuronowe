**AUC** = Area Unde the Curve
**ROC** =Receiver Operating Characteristics
Należy podać próg (kiedy twierdzimy, żę wzorzec należy do klasy pozytywnej)

Im wieksze AUC tym lepszy klasyfikator (lepiej rozróżnia klasy)
![[Pasted image 20221027155228.png | 300]]
 Najlepzy model ma AUC = 1
 AUC = 0 - wskazania klasyfikatora są odwrotne
 AUC = 0.5 - klasyfikator działa losowo

Elementy związane z [[Macierz pomyłek|macierzą pomyłek]]
TPR - true positive ratio
FPF - false positive ratio

